# Ecomerce de pedido de comida em restaurante
Neste curso "Site de pedido de comida", eu aprendi a criar um site completo, dinâmico e totalmente funcional, usando a linguagem de programação PHP e banco de dados MySQL. "Site de pedido de comida com PHP e MySQLI".

<img height="180em" src="https://github-readme-stats.vercel.app/api?username=alfabar&show_icons=true&hide_border=true&&count_private=true&include_all_commits=true" />

## Tecnologias utilizadas
1. HTML5
2. CSS3
3. PHP
4. MySqli

**Referência**

treinamento adquirido com muito respeito ao mestre Vijay Thapa. Agradeço muito a sua pessoa por disponibilizar exelentes cursos gratuito em sua pagina no youtube, me dediquei imensamente neste projeto com a finalidade de aprender e aprender cada vez mais e agregar ao meus estudos que já venho realizando No momento compartilhar este mesmo sentimento que tive e um prazer aos meus colegas e amigos 
[Site de pedido de comida com PHP e MySQL](https://youtu.be/ZBgTzx46B8s)
