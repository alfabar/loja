 <!-- footer seção começo -->
 <div class="footer">

<div class="wrapper"><p class="text-center">2021 all rights reserved, Some Restaurant. developed by Adriano Baram  a
     </p></div>

</div>
<!-- footer seção fim -->

<script src="" async defer></script>
</body>

</html>